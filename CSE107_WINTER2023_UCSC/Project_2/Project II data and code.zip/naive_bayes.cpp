/*********************************************
python code for project naive bayes classifier
in CSE 107 in 2022 winter, UC Santa Cruz
Student Name: ____
UW Email    : ____@ucsc.edu
=============================================================
You may define helper functions, but DO NOT MODIFY
the parameters or names of the provided functions.
=============================================================
*********************************************/

#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>
#include <set>
#include <fstream>
#include <filesystem>
/*********************************************
===================== ABOUT THE DATA ========================
Inside the 'data' folder, the emails are separated into 'train' 
and 'test' data. Each of these folders has nested 'spam' and 'ham'
folders, each of which has a collection of emails as txt files.
You will only use the emails in the 'train' folder to train your 
classifier, and will evaluate on the 'test' folder.
        
The emails we are using are a subset of the Enron Corpus,
which is a set of real emails from employees at an energy
company. The emails have a subject line and a body, both of
which are 'tokenized' so that each unique word or bit of
punctuation is separated by a space or newline. The starter
code provides a function that takes a filename and returns a
set of all of the distinct tokens in the file.
=============================================================
*********************************************/
namespace fs = std::filesystem;

class NaiveBayes{
public:

    NaiveBayes(){

        // These variables are described in the 'fit' function below. 
        // You will also need to access them in the 'predict' function.
        num_train_hams = 0;
        num_train_spams = 0;
        word_counts_ham.clear();
        word_counts_spam.clear();
        HAM_LABEL = "ham";
        SPAM_LABEL = "spam";

        train_hams.clear();
        train_spams.clear();
        test_hams.clear();
        test_spams.clear();
    }

    void load_data(){
        // train_hams train_spams test_hams test_spams
        // are vectors of strings that stores
        // the data set. Each element in the vector is a 
        // filename. The file should contains an email
        // that is either a spam or a ham
        // You do not need to worry about how this
        // function works unless you're curious.

        std::string path = "./data/train/ham";
        for (const auto & entry : fs::directory_iterator(path))
            train_hams.push_back(entry.path());

        path = "./data/train/spam";
        for (const auto & entry : fs::directory_iterator(path))
            train_spams.push_back(entry.path());

        path = "./data/test/ham";
        for (const auto & entry : fs::directory_iterator(path))
            test_hams.push_back(entry.path());

        path = "./data/test/spam";
        for (const auto & entry : fs::directory_iterator(path))
            test_spams.push_back(entry.path());
    }

    std::set<std::string> word_set(std::string filename) {
    //This function reads in a file and returns a set of all 
    //the words. It ignores the subject line.

    //:param filename: The filename of the email to process.
    //:return: A set of all the unique word in that file.

    //For example, if the email had the following content:
    //Subject: Get rid of your student loans
    //Hi there,
    //If you work for us, we will give you money
    //to repay your student loans. You will be
    //debt free!
    //FakePerson_22393

    //This function would return to you the set:
    //{'', 'work', 'give', 'money', 'rid', 'your', 'there,',
    //     'for', 'Get', 'to', 'Hi', 'you', 'be', 'we', 'student',
    //     'debt', 'loans', 'loans.', 'of', 'us,', 'will', 'repay',
    //     'FakePerson_22393', 'free!', 'You', 'If'}
        std::set<std::string> result;
        result.clear();
        
        std::ifstream in(filename);
        char* str = new char[500];
        while(in){
            in.getline(str, 255);
            char * tempPtr = strtok(str," ");
            while(tempPtr)
            {
                result.insert(std::string(tempPtr));
                tempPtr = strtok(NULL," ");
            }
        }
        in.close();
        return result;
    
    
    }
    
    void fit() {
        // At the end of this function, the following should be true:
        // 1. num_train_hams is set to the number of ham emails given.
        // 2. num_train_spams is set to the number of spam emails given.
        // 3. word_counts_spam is a DICTIONARY where word_counts_spam[word]
        // is the number of spam emails which contained this word. 
        // 4. word_counts_ham is a DICTIONARY where word_counts_ham[word]
        // is the number of ham emails which contained this word. 

        // Hint(s):
        // 1. You may want to use the word_set function provided.
        // 2. You should not worry about Laplace smoothing or anything here:
        // simply make sure your counts are correct from the data you're given.

        //TODO: Your code here (20-30 lines)
    }

    std::string predict(std::string filename) {
        // :param filename: The filename of an email to classify.
        // :return: The prediction of our Naive Bayes classifier. This
        // should either return HAM_LABEL or SPAM_LABEL.

        // Guidelines:
        // 1. Make sure to use the log-trick to avoid underflow.
        // 2. Make sure for Laplace smoothing you use +1 in numerator 
        // and +2 in denominator. This is even for words you haven't seen before
        // in the training data, which would otherwise have 0 probability.
        // 3. Remember, the goal is not 100% accuracy - a correct implementation will get
        // exactly a certain accuracy.
        // 4. In case of a tie, predict 'self.HAM_LABEL'.
        // 5. Do NOT apply Laplace smoothing to P(ham) and P(spam).

        // Hint(s):
        // 1. You may want to use the word_set function provided.
        // 2. For a dictionary d, d[key] returns the value if the key exists.
        // But if it doesn't, you get an error.
        // 3. You'll want to use the values you set during the fit function.
        // Access those variables with a 'self' prefix, like num_train_hams.

        // TODO: Your code here (10-20 lines) This is a very simple (and stupid) classier
        // it just returns ham anyway

        return HAM_LABEL;
    }

    double accuracy(std::vector<std::string> hams, std::vector<std::string> spams) {
        uint64_t total_correct = 0;
        uint64_t total_datapoints = hams.size() + spams.size();
        for (auto filename: hams) {
            if (predict(filename) == HAM_LABEL) {
                total_correct++;
            }
        }

        for (auto filename: spams) {
            if (predict(filename) == SPAM_LABEL) {
                total_correct++;
            }
        }

        return double(total_correct) / total_datapoints;
    }


public:

    uint64_t num_train_hams;
    uint64_t num_train_spams;
    std::map<std::string, uint64_t> word_counts_ham;
    std::map<std::string, uint64_t> word_counts_spam;
    std::string HAM_LABEL;
    std::string SPAM_LABEL;

    std::vector<std::string> train_hams;
    std::vector<std::string> train_spams;
    std::vector<std::string> test_hams;
    std::vector<std::string> test_spams;


};


int main()
{
    NaiveBayes nbc;
    nbc.load_data();
    nbc.fit();
    std::cout << "Train Accuracy: " << nbc.accuracy(nbc.train_hams, nbc.train_spams) << std::endl;
    std::cout << "Test Accuracy: " << nbc.accuracy(nbc.test_hams, nbc.test_spams) << std::endl;
    return 0;
}