I used the example code for "blink" which did not seem to turn on or off the LED, 

however, there was output to terminal:
  "example: Turning the LED ON !"
  "example: Turning the LED ON !"