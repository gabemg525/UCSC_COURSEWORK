#ifdef __cplusplus
extern "C" {
#endif
  void i2c_master_init(); 
  // void app_main();

#ifdef __cplusplus
}
#endif